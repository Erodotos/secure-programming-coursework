<?php 

//For admin only
//For error checking and debugging only
phpinfo();

?>
